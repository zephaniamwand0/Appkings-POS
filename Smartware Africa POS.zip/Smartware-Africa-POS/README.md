# Smartware Africa POS

* A small POS App that can pick items from a list where prices are also specified...
* You can add your products to the POS
* Allow capture of more than one item on the same sale receipt
* Print a receipt in PDF
* User management facility.
